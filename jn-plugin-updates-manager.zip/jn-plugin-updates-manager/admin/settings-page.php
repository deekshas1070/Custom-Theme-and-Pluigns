<?php

function jn_render_settings_page()
{
    $all_plugins = get_plugins();
    $disabled_plugins = get_option('jn_disabled_plugins', []);
?>
    <div class="wrap">
        <h1 class="main-hdng">Disable Plugin Updates</h1>

        <form method="post" action="options.php">
            <?php settings_fields('jn_settings_group'); ?>
            <div class="jn-flex-container">

                <!-- Left Column -->
                <div class="jn-left">


                    <div class="plugin-list">
                        <label for="plugin-selector"><strong>Select Plugin:</strong></label><br>
                        <select id="plugin-selector">
                            <option value="">-- Select Plugin --</option>
                            <?php foreach ($all_plugins as $path => $plugin_data): ?>
                                <option value="<?php echo esc_attr($path); ?>">
                                    <?php echo esc_html($plugin_data['Name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    

                    <div class="button-holder">
                        <button type="button" id="select-all-plugins" class="button">Select All Plugins</button>
                    </div>
                </div>


                <!-- Right Column -->
                <div class="jn-right">

                    <div class="plugin-list">
                        <label><strong>Disabled Plugin List:</strong></label><br>
                        <div id="selected-plugins" class="jn-tag-box">
                            <?php foreach ($disabled_plugins as $plugin): ?>
                                <span class="plugin-tag" data-plugin="<?php echo esc_attr($plugin); ?>">
                                    <?php echo esc_html($all_plugins[$plugin]['Name'] ?? $plugin); ?>
                                </span>
                            <?php endforeach; ?>
                        </div>
                        <small>Click on specific plugin  to remove from the list</small>
                    </div>


                    <div class="button-holder">
                        <button type="button" id="remove-all-plugins" class="button">Remove All Plugins</button><br><br>
                    </div>
                </div>

            </div>

            <input type="hidden" id="jn_disabled_plugins_input" name="jn_disabled_plugins" value="<?php echo esc_attr(implode(',', $disabled_plugins)); ?>">

            <p class="submit">
                <button type="submit" class="button button-primary">Save Settings</button>
            </p>
        </form>
    </div>
<?php
}
