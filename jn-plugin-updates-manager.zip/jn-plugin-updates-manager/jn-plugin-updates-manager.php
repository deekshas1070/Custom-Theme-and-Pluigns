<?php
/*
Plugin Name: Plugin Updates Manager
Description: A simple plugin to manage and disable updates for specific plugins.
Version: 1.0.0
Author: Aditya Chauhan
*/

// P l u g i n U R I: https://example.com/plugin-updates-manager
if (!defined('ABSPATH')) exit;

// Add settings page
add_action('admin_menu', function () {
    add_options_page(
        'Disable Plugin Updates',
        'Disable Plugin Updates',
        'manage_options',
        'disable-plugin-updates',
        'jn_render_settings_page'
    );
});

// Load settings page content
require_once plugin_dir_path(__FILE__) . 'admin/settings-page.php';

// Register option
add_action('admin_init', function () {
    register_setting('jn_settings_group', 'jn_disabled_plugins', [
        'sanitize_callback' => function($input) {
            if (is_string($input)) {
                return array_filter(array_map('trim', explode(',', $input)));
            }
            return [];
        }
    ]);
});

// Disable updates for selected plugins
add_action('plugins_loaded', function () {
    add_filter('site_transient_update_plugins', function ($value) {
        $disabled_plugins = get_option('jn_disabled_plugins', []);
        if (isset($value) && is_object($value)) {
            foreach ($disabled_plugins as $plugin) {
                if (isset($value->response[$plugin])) {
                    unset($value->response[$plugin]);
                }
            }
        }
        return $value;
    });
});

// Enqueue admin scripts and styles
add_action('admin_enqueue_scripts', function($hook) {
    if ($hook !== 'settings_page_disable-plugin-updates') return;

    wp_enqueue_style(
        'jn-admin-style',
        plugin_dir_url(__FILE__) . 'assets/css/admin-style.css',
        [],
        '1.0'
    );

    wp_enqueue_script(
        'jn-admin-script',
        plugin_dir_url(__FILE__) . 'assets/js/admin-script.js',
        ['jquery'],
        '1.0',
        true
    );
});


// Add settings link on the plugin page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'jn_add_settings_link');

function jn_add_settings_link($links) {
    $settings_url = admin_url('options-general.php?page=disable-plugin-updates');
    $settings_link = '<a href="' . esc_url($settings_url) . '">Settings</a>';
    array_unshift($links, $settings_link); // Add at the beginning
    return $links;
}

