<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package jagsness-theme
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<h5 style="text-align:center">Posts Listing Template</h5>
</article><!-- #post-<?php the_ID(); ?> -->


