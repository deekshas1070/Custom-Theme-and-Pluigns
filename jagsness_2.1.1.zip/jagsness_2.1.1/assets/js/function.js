jQuery(function ($) {
    console.log(
        "%cWebsite Built by Aditya Chauhan",
        "background: #0a383f; color: #ffffff; display: block;padding:5px 15px;border-radius:7px"
    );
})
