jQuery("#vid_popup").click(function () {
    jQuery(".vid_popup_wrapper").addClass('active');
  })
  jQuery(".close_popup").on("click", function () {
    var popup = jQuery(".vid_popup_wrapper");
    var video = popup.find("video")[0]; 
    if (video) { 
      video.pause();
      video.currentTime = 0;
    }
    popup.removeClass('active');
  });

  jQuery(".vid_popup_wrapper").on("click", function (e) {
    if (jQuery(e.target).is(".vid_popup_wrapper")) {
      var video = jQuery(this).find("video")[0];
      if (video) {
        video.pause();
        video.currentTime = 0;
      }
      jQuery(this).removeClass('active');
    }
  });

  jQuery(document).on("keydown", function (e) {
    if (e.keyCode == 27) { // Escape key
      var popup = jQuery(".vid_popup_wrapper");
      var video = popup.find("video")[0];
      if (video) {
        video.pause();
        video.currentTime = 0;
      }
      popup.removeClass('active');
    }
  });

    jQuery('a.woocommerce-pdf-button').click(function() {
    var form_id = jQuery(this).find('input[name="form_id"]').val();
    console.log(form_id);

    // Make AJAX request to generate the PDF
   jQuery.ajax({
        type: 'POST',
        dataType: 'json',
        url: my_ajax_object.ajax_url,
         data: {
            action: 'handle_generate_pdf',
            form_id: form_id
        },
        success: function(response) {
            if (response.data && response.data.pdf_url) {
                var pdfUrl = response.data.pdf_url;

                // Open a new tab and display the PDF using an iframe
                let newTab = window.open();
                newTab.document.write(`
                    <html>
                    <head>
                        <style>
                            body {
                                margin: 0;
                                padding: 0;
                                height: 100%;
                                overflow: hidden;
                            }
                            iframe {
                                width: 100%;
                                height: 100%;
                                border: none;
                                display: block;
                            }
                        </style>
                    </head>
                    <body>
                        <iframe src="${pdfUrl}" width="100%" height="100%"></iframe>
                    </body>
                    </html>
                `);
                newTab.document.close();
            } else {
                console.log('PDF URL is missing in the response.');
            }
        },
        error: function(xhr, status, error) {
            console.log('AJAX error: ' + error);
        }
    });
});

if (typeof currentSection != 'undefined') {
    const sections = document.querySelectorAll(".form-section");
    console.log("printed" + currentSection);
    const nextBtn = document.getElementById("nextBtn");
    const saveBtn = document.getElementById("saveBtn");
    const prevBtn = document.getElementById("prevBtn");
    const submitBtn = document.getElementById("submitBtn");

  function showSection(index) {
    sections.forEach((section, i) => {
      section.classList.toggle("active", i === index);
    });

    // Update button visibility
    prevBtn.style.display = (index ?? 0) > 0 ? "inline-block" : "none";
    nextBtn.style.display = index < sections.length - 1 ? "inline-block" : "none";
	saveBtn.style.display = index < sections.length - 1 ? "inline-block" : "none";
    submitBtn.style.display = index === sections.length - 1 ? "inline-block" : "none";
  }

  // Initially show first section
  showSection(currentSection);

  nextBtn.addEventListener("click", () => {
	  let formAction = 'next';
    if (currentSection < sections.length - 1) {
      currentSection++;
      submitData(formAction)
      showSection(currentSection);
    }
  });
  
   saveBtn.addEventListener("click", () => {
	let formAction = 'save';
    if (currentSection < sections.length - 1) {
      document.querySelector(".loader").classList.remove("hide");
		document.querySelector("#saveBtn").setAttribute("disabled", true);
      submitData(formAction)
      // showSection(currentSection);
    }
  });

  submitBtn.addEventListener("click", (event) => {
    event.preventDefault();
	  let formAction = 'submit';
    document.querySelector(".submitWrap .loader").classList.remove("hide");
    document.querySelector(".submitWrap button").setAttribute("disabled", true);
    submitData(formAction)
  });

  prevBtn.addEventListener("click", () => {
    if (currentSection > 0) {
      currentSection--;
      showSection(currentSection);
    }
  });

  // Conditional logic for visible frosting
  const visibleFrosting = document.getElementById("visibleFrosting");
  const frostingDetails = document.getElementById("frostingDetails");
  visibleFrosting.addEventListener("change", () => {
    frostingDetails.style.display = visibleFrosting.value === "yes" ? "block" : "none";
  });

  // Conditional logic for dye color
  const hasDyeColor = document.getElementById("hasDyeColor");
  const dyeFields = document.getElementById("dyeFields");
  hasDyeColor.addEventListener("change", () => {
    dyeFields.style.display = hasDyeColor.value === "yes" ? "block" : "none";
  });

  // Conditional logic for dye stabilizer
  const hasDyeStabilizer = document.getElementById("hasDyeStabilizer");
  const stabilizerFields = document.getElementById("stabilizerFields");
  hasDyeStabilizer.addEventListener("change", () => {
    stabilizerFields.style.display = hasDyeStabilizer.value === "yes" ? "block" : "none";
  });

  function submitData(formAction) {
    let formData = {};
    const activeSection = jQuery(".form-section.active");
    let getCurrentId = activeSection.attr("id");
    console.log(getCurrentId);
    formData['step'] = getCurrentId;


    if (activeSection.length) {
      // Find all inputs, selects, and textareas inside the active section
      const fields = activeSection.find("input, select, textarea");

      // Example: Log the fields' values
      fields.each(function () {
        const name = jQuery(this).attr("name") || jQuery(this).attr("id");
        const value = jQuery(this).val();
        if (name) {
          formData[name] = value;
        }
      });

      // Make the AJAX call
      jQuery.ajax({
        type: "POST",
        dataType: 'json',
        url: my_ajax_object.ajax_url,
        data: {
            action: "submit_form_data",
            formData: formData
        },
        success: function (response) {
          if (getCurrentId == 'notes' && response.success == true) {
            window.location.href = "/my-account/form-list/";
          }
		  if(formAction == 'save'){
			window.location.href = "/my-account/form-list/";
		  }
        },
        error: function (error) {
          // console.error("Error:", error);
        }
      });
    }

  }
}