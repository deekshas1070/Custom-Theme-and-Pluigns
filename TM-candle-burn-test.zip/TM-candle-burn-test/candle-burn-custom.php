<?php
/*
Plugin Name: TM Candle Burn Test
Description: A simple custom plugin.
Version: 1.0
Author: Techmind
*/
require_once(ABSPATH . 'wp-load.php');

wp_enqueue_style( 'my-plugin-styles', plugins_url( 'assets/css/candelburn-style.css', __FILE__ ) );
add_action( 'wp_enqueue_scripts', 'my_plugin_enqueue_scripts' );
function my_plugin_enqueue_scripts() {
    wp_enqueue_script(
        'candleburn-script',
        plugin_dir_url( __FILE__ ) . 'assets/js/candleburn-script.js',
        array( 'jquery' ),
        '4.0.0',
        true
    );

    wp_localize_script( 'candleburn-script', 'my_ajax_object', array(
        'ajax_url' => admin_url( 'admin-ajax.php' )
    ));
}

require_once plugin_dir_path( __FILE__ ) . 'inc\code\tools-endpoint.php';

add_action( 'init', 'tm_add_tools_endpoint' );
function tm_add_tools_endpoint() {
    add_rewrite_endpoint( 'tools', EP_ROOT | EP_PAGES );
}

register_activation_hook( __FILE__, 'tm_flush_rewrite_rules' );
function tm_flush_rewrite_rules() {
    tm_add_tools_endpoint();
    flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'tm_deactivate_plugin' );
function tm_deactivate_plugin() {
    flush_rewrite_rules();
}

add_action( 'wp_ajax_submit_form_data', 'submit_form_data' );
add_action( 'wp_ajax_nopriv_submit_form_data', 'submit_form_data' );
function submit_form_data() {
    require_once plugin_dir_path( __FILE__ ) . 'inc\code\forms.php';
}

function handle_generate_pdf() {
	$form_id = intval($_POST['form_id']);
    if (isset($form_id)) {
        require_once plugin_dir_path( __FILE__ ) . 'inc\code\includes\create_pdf.php';
    } else {
        wp_send_json_error("Form ID not provided.");
    }
}
add_action('wp_ajax_handle_generate_pdf', 'handle_generate_pdf'); 
add_action('wp_ajax_nopriv_handle_generate_pdf', 'handle_generate_pdf');

function load_form_data_on_page_load() {
    require_once plugin_dir_path( __FILE__ ) . 'inc\code\formload_function.php';
}
add_action('wp', 'load_form_data_on_page_load');
?>