<?php 
$form_step = isset($_SESSION['form_data']['form_step']) ? esc_attr($_SESSION['form_data']['form_step']) : '0';
$ajaxUrl = plugins_url( 'TM-candle-burn-test\inc\code\forms.php' );
?>
<script>
   var redirecturl = "<?php echo $ajaxUrl; ?>";
   let currentSection = <?php echo $form_step ?>;
</script>
<div class="row row-main">
<p class="form_message">Make sure to click 'Save & Exit' to save your form progress before quitting.</p>
   <div class="large-12 col">
      <form id="burnTestForm">
         <h3>Candle Burn-Test Log</h3>
         <!-- Test Details Section -->
         <div class="form-section " id="testDetails">
            <h4>Test Details</h4>
            <label for="testName">Test Name:</label>
            <input type="text" id="testName" name="test_name" placeholder="e.g., Soy Wax Test #1" required value="<?php echo isset($_SESSION['form_data']['name']) ? esc_attr($_SESSION['form_data']['name']) : ''; ?>">
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required value="<?php echo isset($_SESSION['form_data']['date']) ? esc_attr($_SESSION['form_data']['date']) : ''; ?>">
            <label for="indoorTemp">Indoor Temperature (°C):</label>
            <input type="number" id="indoorTemp" name="indoor_temp" required value="<?php echo isset($_SESSION['form_data']['indoor_temperature']) ? esc_attr($_SESSION['form_data']['indoor_temperature']) : ''; ?>">
            <label for="outdoorTemp">Outdoor Temperature (°C):</label>
            <input type="number" id="outdoorTemp" name="outdoor_temp" required value="<?php echo isset($_SESSION['form_data']['outdoor_temperature']) ? esc_attr($_SESSION['form_data']['outdoor_temperature']) : ''; ?>">
         </div>
         <!-- Informational Slide Before Material Details -->
         <div class="form-section" id="infoSlide1">
            <h4>Important Information</h4>
            <p>
               The next section is in regards to how you made your candle. Be as thorough as possible to ensure you have detailed your candle-making process accurately. This will help you to assess the strong and weak points of your candle-making process.
            </p>
         </div>
         <!-- Material Details Section -->
         <div class="form-section" id="materialDetails">
            <h4>Material Details</h4>
            <label for="typeOfWax">Type of Wax:</label>
            <input type="text" id="typeOfWax" name="type_of_wax" placeholder="e.g., Soy, Paraffin" required value="<?php echo isset($_SESSION['form_data']['wax_type']) ? esc_attr($_SESSION['form_data']['wax_type']) : ''; ?>">
            <label for="waxSupplier">Supplier of Wax:</label>
            <input type="text" id="waxSupplier" name="wax_supplier" placeholder="e.g., ABC Wax Supplies" required value="<?php echo isset($_SESSION['form_data']['wax_supplier']) ? esc_attr($_SESSION['form_data']['wax_supplier']) : ''; ?>">
            <label for="amountOfWax">Amount of Wax (g):</label>
            <input type="number" id="amountOfWax" name="amount_of_wax" required value="<?php echo isset($_SESSION['form_data']['wax_amount']) ? esc_attr($_SESSION['form_data']['wax_amount']) : ''; ?>">
            <label for="typeOfWick">Type of Wick:</label>
            <input type="text" id="typeOfWick" name="type_of_wick" placeholder="e.g., Cotton, Wooden" required value="<?php echo isset($_SESSION['form_data']['wick_type']) ? esc_attr($_SESSION['form_data']['wick_type']) : ''; ?>">
            <label for="numberOfWicks">Number of Wicks:</label>
            <input type="number" id="numberOfWicks" name="number_of_wicks" required value="<?php echo isset($_SESSION['form_data']['wick_number']) ? esc_attr($_SESSION['form_data']['wick_number']) : ''; ?>">
            <label for="wickSupplier">Wick Supplier:</label>
            <input type="text" id="wickSupplier" name="wick_supplier" placeholder="e.g., XYZ Wick Co." required value="<?php echo isset($_SESSION['form_data']['wick_supplier']) ? esc_attr($_SESSION['form_data']['wick_supplier']) : ''; ?>">
            <!-- Fragrance Oil -->
            <label for="fragranceOilName">Fragrance Oil Name:</label>
            <input type="text" id="fragranceOilName" name="fragrance_oil_name" placeholder="e.g., Lavender Bliss" required value="<?php echo isset($_SESSION['form_data']['fragrance_oil_name']) ? esc_attr($_SESSION['form_data']['fragrance_oil_name']) : ''; ?>">
            <label for="fragranceVolumeAndLoad">Volume & Percentage Load (e.g., 10ml, 8%):</label>
            <input type="text" id="fragranceVolumeAndLoad" name="fragrance_volume_load" placeholder="e.g., 10ml, 8%" required value="<?php echo isset($_SESSION['form_data']['volume_and_percentage_load']) ? esc_attr($_SESSION['form_data']['volume_and_percentage_load']) : ''; ?>">
            <label for="fragranceSupplier">Fragrance Supplier:</label>
            <input type="text" id="fragranceSupplier" name="fragrance_supplier" placeholder="e.g., ScentWorks" required value="<?php echo isset($_SESSION['form_data']['fragrance_supplier']) ? esc_attr($_SESSION['form_data']['fragrance_supplier']) : ''; ?>">
            <!-- Dye Color -->
            <label for="hasDyeColor">Use Dye Color? (Yes/No):</label>
            <select id="hasDyeColor" name="has_dye_color">
               <option value="no" <?php echo isset($_SESSION['form_data']['has_dye_color']) && $_SESSION['form_data']['has_dye_color'] == 'no' ? 'selected' : ''; ?>>No</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['has_dye_color']) && $_SESSION['form_data']['has_dye_color'] == 'yes' ? 'selected' : ''; ?>>Yes</option>
            </select>
            <div id="dyeFields" style="display: none;">
               <label for="dyeColor">Dye Color:</label>
               <input type="text" id="dyeColor" name="dye_color" placeholder="e.g., Red, Blue, Yellow" value="<?php echo isset($_SESSION['form_data']['dye_color']) ? esc_attr($_SESSION['form_data']['dye_color']) : ''; ?>">
               <label for="volumeOfDye">Volume of Dye (ml):</label>
               <input type="number" id="volumeOfDye" name="volume_of_dye" step="0.01" value="<?php echo isset($_SESSION['form_data']['volume_of_dye']) ? esc_attr($_SESSION['form_data']['volume_of_dye']) : ''; ?>">
            </div>
            <!-- Wax Stabilizer -->
            <label for="hasDyeStabilizer">Use Dye Stabilizer? (Yes/No):</label>
            <select id="hasDyeStabilizer" name="has_dye_stabilizer">
               <option value="no" <?php echo isset($_SESSION['form_data']['dye_stabilizer']) && $_SESSION['form_data']['dye_stabilizer'] == 'no' ? 'selected' : ''; ?>>No</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['dye_stabilizer']) && $_SESSION['form_data']['dye_stabilizer'] == 'yes' ? 'selected' : ''; ?>>Yes</option>
            </select>
            <div id="stabilizerFields" style="display: none;">
               <label for="stabilizerType">Dye Stabilizer Type:</label>
               <input type="text" id="stabilizerType" name="stabilizer_type" placeholder="e.g., Liquid, Powder" value="<?php echo isset($_SESSION['form_data']['stabilizer_type']) ? esc_attr($_SESSION['form_data']['stabilizer_type']) : ''; ?>">
               <label for="volumeOfDyeStabilizer">Volume of Dye Stabilizer (ml):</label>
               <input type="number" id="volumeOfDyeStabilizer" name="volume_of_dye_stabilizer" step="0.01" value="<?php echo isset($_SESSION['form_data']['volume_of_dye_stabilizer']) ? esc_attr($_SESSION['form_data']['volume_of_dye_stabilizer']) : ''; ?>">
            </div>
            <!-- Wax Details -->
            <label for="waxMeltingTemp">Wax Melting Temperature (°C):</label>
            <input type="number" id="waxMeltingTemp" name="wax_melting_temp" value="<?php echo isset($_SESSION['form_data']['wax_melting_temperature']) ? esc_attr($_SESSION['form_data']['wax_melting_temperature']) : ''; ?>">
            <label for="blendingTemp">Blending Temperature (°C):</label>
            <input type="number" id="blendingTemp" name="blending_temp" value="<?php echo isset($_SESSION['form_data']['blending_temperature']) ? esc_attr($_SESSION['form_data']['blending_temperature']) : ''; ?>">
            <label for="pouringTemp">Pouring Temperature (°C):</label>
            <input type="number" id="pouringTemp" name="pouring_temp" value="<?php echo isset($_SESSION['form_data']['pouring_temperature']) ? esc_attr($_SESSION['form_data']['pouring_temperature']) : ''; ?>">
            <label for="coolingTime">Cooling Time (hours):</label>
            <input type="number" step="0.01" id="coolingTime" name="cooling_time" value="<?php echo isset($_SESSION['form_data']['cooling_time']) ? esc_attr($_SESSION['form_data']['cooling_time']) : ''; ?>">
            <!-- Container Details -->
            <label for="containerType">Container Type:</label>
            <input type="text" id="containerType" name="container_type" placeholder="Oxford Style Candle Jar" required value="<?php echo isset($_SESSION['form_data']['container_type']) ? esc_attr($_SESSION['form_data']['container_type']) : ''; ?>">
            <label for="containerSupplier">Container Supplier:</label>
            <input type="text" id="containerSupplier" name="container_supplier" placeholder="Wic Supplies" required value="<?php echo isset($_SESSION['form_data']['container_supplier']) ? esc_attr($_SESSION['form_data']['container_supplier']) : ''; ?>">
            <label for="containerSize">Container Size:</label>
            <input type="text" id="containerSize" name="container_size" placeholder="e.g., 8oz, 250ml" required value="<?php echo isset($_SESSION['form_data']['container_size']) ? esc_attr($_SESSION['form_data']['container_size']) : ''; ?>">
         </div>
         <!-- Informational Slide Before Performance Details -->
         <div class="form-section" id="infoSlide2">
            <h4>Congratulations!</h4>
            <p>
               Congratulations, you have made your candle. Before you progress to the next section, allow your candle to cure. The next section is all about the burn quality of your candle. Come back to this section when you are ready to assess the burn quality of your candle.
            </p>
            <p>
               If you're ready to burn now, it's time to monitor and assess the burn quality of your candle at different time increments.
            </p>
         </div>
         <!-- Performance Details Section -->
         <div class="form-section" id="performanceDetails">
            <h4>Performance Details</h4>
            <!-- Cold Fragrance Throw -->
            <label for="coldFragranceThrow">Cold Fragrance Throw Rating (1-10):</label>
            <input type="number" id="coldFragranceThrow" name="cold_fragrance_throw" min="1" max="10" required value="<?php echo isset($_SESSION['form_data']['cold_fragrance_throw_rating']) ? esc_attr($_SESSION['form_data']['cold_fragrance_throw_rating']) : ''; ?>">
            <!-- Visible Frosting -->
            <label for="visibleFrosting">Visible Frosting (Y/N):</label>
            <select id="visibleFrosting" name="visible_frosting" required>
               <option value="no" <?php echo isset($_SESSION['form_data']['has_visible_frosting']) && $_SESSION['form_data']['has_visible_frosting'] == 'no' ? 'selected' : ''; ?>>No</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['has_visible_frosting']) && $_SESSION['form_data']['has_visible_frosting'] == 'yes' ? 'selected' : ''; ?>>Yes</option>
            </select>
            <div id="frostingDetails" style="display: none;">
               <label for="frostingLocation">If yes, where?</label>
               <input type="text" id="frostingLocation" name="frosting_location" placeholder="e.g., On the sides, bottom" value="<?php echo isset($_SESSION['form_data']['visible_frosting']) ? esc_attr($_SESSION['form_data']['visible_frosting']) : ''; ?>">
               <label for="frostingAmount">Amount:</label>
               <input type="text" id="frostingAmount" name="frosting_amount" placeholder="e.g., Heavy, Light" value="<?php echo isset($_SESSION['form_data']['visible_frosting_amount']) ? esc_attr($_SESSION['form_data']['visible_frosting_amount']) : ''; ?>">
            </div>
            <!-- Subheadings for Candle Burn -->
            <div class="burn-subheading">Candle burn after 1 hour</div>
            <label for="meltToEdge1">Percentage Melted to Edge:</label>
            <input type="text" id="meltToEdge1" name="melt_to_edge_1" placeholder="e.g., 80%" value="<?php echo isset($_SESSION['form_data']['percent_melted_edge_1_hr']) ? esc_attr($_SESSION['form_data']['percent_melted_edge_1_hr']) : ''; ?>">
            <label for="meltPoolDepth1">Depth of Melt Pool (cm):</label>
            <input type="number" id="meltPoolDepth1" name="melt_pool_depth_1" step="0.01" placeholder="e.g., 1.5" value="<?php echo isset($_SESSION['form_data']['melt_pool_depth_1_hr']) ? esc_attr($_SESSION['form_data']['melt_pool_depth_1_hr']) : ''; ?>">
            <label for="smoking1">Amount of Smoking (None/Light/Heavy):</label>
            <select id="smoking1" name="smoking_1">
               <option value="no" <?php echo isset($_SESSION['form_data']['smoking_amount_1_hr']) && $_SESSION['form_data']['smoking_amount_1_hr'] == 'none' ? 'selected' : ''; ?>>None</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['smoking_amount_1_hr']) && $_SESSION['form_data']['smoking_amount_1_hr'] == 'light' ? 'selected' : ''; ?>>Light</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['smoking_amount_1_hr']) && $_SESSION['form_data']['smoking_amount_1_hr'] == 'heavy' ? 'selected' : ''; ?>>Heavy</option>
            </select>
            <label for="notes1">Notes:</label>
            <textarea id="notes1" name="notes_1" rows="3" placeholder="Observations after 1 hour"><?php echo isset($_SESSION['form_data']['notes_1_hr']) ? esc_attr($_SESSION['form_data']['notes_1_hr']) : ''; ?></textarea>
            <div class="burn-subheading">Candle burn after 2 hours</div>
            <label for="meltToEdge2">Percentage Melted to Edge:</label>
            <input type="text" id="meltToEdge2" name="melt_to_edge_2" placeholder="e.g., 90%" value="<?php echo isset($_SESSION['form_data']['percent_melted_edge_2_hr']) ? esc_attr($_SESSION['form_data']['percent_melted_edge_2_hr']) : ''; ?>">
            <label for="meltPoolDepth2">Depth of Melt Pool (cm):</label>
            <input type="number" id="meltPoolDepth2" name="melt_pool_depth_2" step="0.01" placeholder="e.g., 2.0" value="<?php echo isset($_SESSION['form_data']['melt_pool_depth_2_hr']) ? esc_attr($_SESSION['form_data']['melt_pool_depth_2_hr']) : ''; ?>">
            <label for="smoking2">Amount of Smoking (None/Light/Heavy):</label>
            <select id="smoking2" name="smoking_2">
               <option value="no" <?php echo isset($_SESSION['form_data']['smoking_amount_2_hr']) && $_SESSION['form_data']['smoking_amount_2_hr'] == 'none' ? 'selected' : ''; ?>>None</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['smoking_amount_2_hr']) && $_SESSION['form_data']['smoking_amount_2_hr'] == 'light' ? 'selected' : ''; ?>>Light</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['smoking_amount_2_hr']) && $_SESSION['form_data']['smoking_amount_2_hr'] == 'heavy' ? 'selected' : ''; ?>>Heavy</option>
            </select>
            <label for="notes2">Notes:</label>
            <textarea id="notes2" name="notes_2" rows="3" placeholder="Observations after 2 hours"><?php echo isset($_SESSION['form_data']['notes_2_hr']) ? esc_attr($_SESSION['form_data']['notes_2_hr']) : ''; ?></textarea>
            <div class="burn-subheading">Candle burn after 3 hours</div>
            <label for="meltToEdge3">Percentage Melted to Edge:</label>
            <input type="text" id="meltToEdge3" name="melt_to_edge_3" placeholder="e.g., 100%" value="<?php echo isset($_SESSION['form_data']['percent_melted_edge_3_hr']) ? esc_attr($_SESSION['form_data']['percent_melted_edge_3_hr']) : ''; ?>">
            <label for="meltPoolDepth3">Depth of Melt Pool (cm):</label>
            <input type="number" id="meltPoolDepth3" name="melt_pool_depth_3" step="0.01" placeholder="e.g., 2.5" value="<?php echo isset($_SESSION['form_data']['melt_pool_depth_3_hr']) ? esc_attr($_SESSION['form_data']['melt_pool_depth_3_hr']) : ''; ?>">
            <label for="smoking3">Amount of Smoking (None/Light/Heavy):</label>
            <select id="smoking3" name="smoking_3">
               <option value="no" <?php echo isset($_SESSION['form_data']['smoking_amount_3_hr']) && $_SESSION['form_data']['smoking_amount_3_hr'] == 'none' ? 'selected' : ''; ?>>None</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['smoking_amount_3_hr']) && $_SESSION['form_data']['smoking_amount_3_hr'] == 'light' ? 'selected' : ''; ?>>Light</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['smoking_amount_3_hr']) && $_SESSION['form_data']['smoking_amount_3_hr'] == 'heavy' ? 'selected' : ''; ?>>Heavy</option>
            </select>
            <label for="notes3">Notes:</label>
            <textarea id="notes3" name="notes_3" rows="3" placeholder="Observations after 3 hours"><?php echo isset($_SESSION['form_data']['notes_3_hr']) ? esc_attr($_SESSION['form_data']['notes_3_hr']) : ''; ?></textarea>
            <div class="burn-subheading">Candle burn after 4 hours</div>
            <label for="meltToEdge4">Percentage Melted to Edge:</label>
            <input type="text" id="meltToEdge4" name="melt_to_edge_4" placeholder="e.g., 100%" value="<?php echo isset($_SESSION['form_data']['percent_melted_edge_4_hr']) ? esc_attr($_SESSION['form_data']['percent_melted_edge_4_hr']) : ''; ?>">
            <label for="meltPoolDepth4">Depth of Melt Pool (cm):</label>
            <input type="number" id="meltPoolDepth4" name="melt_pool_depth_4" step="0.01" placeholder="e.g., 3.0" value="<?php echo isset($_SESSION['form_data']['melt_pool_depth_4_hr']) ? esc_attr($_SESSION['form_data']['melt_pool_depth_4_hr']) : ''; ?>">
            <label for="smoking4">Amount of Smoking (None/Light/Heavy):</label>
            <select id="smoking4" name="smoking_4">
               <option value="no" <?php echo isset($_SESSION['form_data']['smoking_amount_4_hr']) && $_SESSION['form_data']['smoking_amount_4_hr'] == 'none' ? 'selected' : ''; ?>>None</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['smoking_amount_4_hr']) && $_SESSION['form_data']['smoking_amount_4_hr'] == 'light' ? 'selected' : ''; ?>>Light</option>
               <option value="yes" <?php echo isset($_SESSION['form_data']['smoking_amount_4_hr']) && $_SESSION['form_data']['smoking_amount_4_hr'] == 'heavy' ? 'selected' : ''; ?>>Heavy</option>
            </select>
            <label for="notes4">Notes:</label>
            <textarea id="notes4" name="notes_4" rows="3" placeholder="Observations after 4 hours"><?php echo isset($_SESSION['form_data']['notes_4_hr']) ? esc_attr($_SESSION['form_data']['notes_4_hr']) : ''; ?></textarea>
         </div>
         <!-- Notes Section -->
         <div class="form-section" id="notes">
            <h4>Notes</h4>
            <label for="notes">Additional Notes:</label>
            <textarea id="notes" name="notes" rows="5"><?php echo isset($_SESSION['form_data']['additional_notes']) ? esc_attr($_SESSION['form_data']['additional_notes']) : ''; ?></textarea>
         </div>
         <!-- Navigation Buttons -->
         <div class="navigation-buttons">
            <button type="button" id="prevBtn">Back</button>
			<button type="button" id="saveBtn">Save & Exit</button>
			<span class="loader hide"></span>
            <button type="button" id="nextBtn">Next</button>
         </div>
         <!-- Submit Button (Only on Final Section) -->
         <div class="submitWrap">
            <button type="submit" id="submitBtn" style="display: none;">Submit</button>
            <span class="loader hide"></span>
         </div>
      </form>
   </div>
</div>
