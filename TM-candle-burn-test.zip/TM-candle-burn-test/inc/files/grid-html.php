<?php
    // $current_user = wp_get_current_user();
    // echo $user_id = $current_user->ID;

    // $user_subscriptions = get_user_subscriptions_data($user_id);
    // echo "<pre>"; print_r($user_subscriptions); echo "</pre>";
    // $args = array(
    //     'post_type'      => 'sumosubscriptions',
    //     'post_status'    => array('publish'),
    //     'posts_per_page' => -1,
    //     'author'         => $user_id,
    // );
    // $subscriptions = new WP_Query( $args );
    // if ( $subscriptions->have_posts() ) {
    //     while ( $subscriptions->have_posts() ) {
    //         echo "<pre>"; print_r($subscriptions); echo "</pre>";
    //     }
    // }else {
    //     echo "No subscriptions found for this user.";
    // }
?>
<div class="row row-main">
    <div class="large-12 col">
        <div class="col-inner">
            <div id="text-1753346040" class="text">
                <h1>Welcome to Wic Learning</h1>
                <p>Explore all of our FREE resources to help level up your production, marketing and much more.&nbsp;</p>
            </div>
            <div class="pt-cv-wrapper">
                <div class="pt-cv-view pt-cv-overlaygrid iscvblock iscvhybrid overlay1 layout1" id="pt-cv-view-5b57977dbf">
                    <div data-id="pt-cv-page-1" class="pt-cv-page" data-cvc="3">
                        <div class=" pt-cv-content-item pt-cv-1-col">
                            <div class="pt-cv-thumb-wrapper  ">
                                <a href="/my-account/form-list/" class="_self pt-cv-href-thumbnail pt-cv-thumb-default" target="_self"><img loading="lazy" decoding="async" width="732" height="400" src="https://wicsupplies.com/wp-content/uploads/2025/01/pexels-vlada-karpovich-6755862-2-732x400.jpg" class="pt-cv-thumbnail" alt="" srcset="https://wicsupplies.com/wp-content/uploads/2025/01/pexels-vlada-karpovich-6755862-2-732x400.jpg 732w, https://wicsupplies.com/wp-content/uploads/2025/01/pexels-vlada-karpovich-6755862-2-1400x765.jpg 1400w, https://wicsupplies.com/wp-content/uploads/2025/01/pexels-vlada-karpovich-6755862-2-768x420.jpg 768w, https://wicsupplies.com/wp-content/uploads/2025/01/pexels-vlada-karpovich-6755862-2-1536x839.jpg 1536w" sizes="auto, (max-width: 732px) 100vw, 732px"></a>
                            </div>
                            <div class="pt-cv-overlay-wrapper">
                                <h4 class="pt-cv-title"><a href="/my-account/form-list/" class="_self" target="_self">Candle Burn Test Log</a></h4>
                                <div class="pt-cv-content">
                                    <div class="pt-cv-rmwrap">
                                        <a href="/my-account/form-list/" class="_self pt-cv-readmore btn btn-success" target="_self">Access</a>
                                    </div>
                                </div>
                            </div>

                            <a href="/my-account/form-list/" class="absolute_link"></a>
                        </div>
                    </div>
                </div>
            </div>
            <style type="text/css" id="pt-cv-inline-style-67dad5euto">
                #pt-cv-view-5b57977dbf .pt-cv-thumb-wrapper::before {background: rgba(0,0,0,.4); opacity: 0.8;}#pt-cv-view-5b57977dbf .pt-cv-overlay-wrapper {justify-content: flex-end;}
                #pt-cv-view-5b57977dbf > .pt-cv-page {grid-template-columns: repeat(2, 1fr);grid-auto-rows: 250px;grid-gap: 15px;}
                @media all and (max-width: 1024px) { 
                #pt-cv-view-5b57977dbf > .pt-cv-page {grid-template-columns: repeat(1, 1fr);}
                } 
                @media all and (max-width: 767px) { 
                #pt-cv-view-5b57977dbf > .pt-cv-page {grid-template-columns: repeat(1, 1fr);}
                }
            </style>
        </div>
    </div>
</div>