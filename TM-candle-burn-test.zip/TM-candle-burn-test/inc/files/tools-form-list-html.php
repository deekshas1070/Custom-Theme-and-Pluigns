<?php

get_header();

global $wpdb;

$current_user = wp_get_current_user();
$user_id = $current_user->ID;
if($user_id ){
	$table_name = $wpdb->prefix . 'candle_burn_form';
	$results = $wpdb->get_results("SELECT * FROM $table_name where user_id = $user_id ORDER BY created_at DESC", ARRAY_A);
}else{
	$results = array();
}
?>
<div class="row row-main">
  <div class="large-12 col">
    <div class="list_header">
      <div>
        <h4>
          Create a new form
          <div class="left_button_group">
            <a href="JavaScript:void(0)" id="vid_popup">How to use the Log?</a>
            <a href="/my-account/tools-form/">Start New Log</a>
          </div>
        </h4>
      </div>
    </div>
    <div class="vid_popup_wrapper">
      <div class="vk_vid_popup">
      <video controls>
        <source src="http://wicsupplies.com/wp-content/uploads/2025/03/Candle-Log-Instructional-2.mp4" type="video/mp4">
      </video>
      <div class="close_popup">X</div>
      </div>
    </div>
    <table class="table tool-form-list">
      <thead>
        <tr>
          <!-- <th scope="col">#</th> -->
          <th scope="col">Form Name</th>
          <th scope="col">Date</th>
          <th scope="col">Status</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($results)) : ?>
          <?php foreach ($results as $index => $row) : ?>
            <tr>
              <!-- <th scope="row">?php echo esc_html($index + 1); ?</th> -->
              <td><?php echo esc_html($row['name']); ?></td>
              <td><?php echo date('M d, Y', strtotime($row['date'])); ?></td>
              <td><?php echo esc_html($row['form_status']); ?></td>
              <td>
                <?php if ($row['form_status'] === 'Processing' || $row['form_status'] === 'Ready to Burn') : ?>
                  <a href="/my-account/tools-form/?form_id=<?php echo esc_attr($row['id']); ?>" class="woocommerce-button button view">
                    Resume
                  </a>
                <?php else : ?>
                  <a href='javascript:void(0)' class="woocommerce-pdf-button">
				            <input type="hidden" name='form_id' value='<?php echo esc_attr($row['id']); ?>' />
                    <img src="<?php echo plugins_url( 'TM-candle-burn-test\assets\images\pdf.png' ); ?>" alt="PDF">
                  </a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else : ?>
          <tr>
            <td colspan="5">No forms found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
  jQuery(document).ready(function($) {
	  $.fn.dataTable.ext.errMode = 'none';
    $('.tool-form-list').DataTable({
      "paging": true,
      "ordering": false,
      "info": false,
      "dom": '<"top"i>rt<"bottom"p><"clear">',
	  "error": function (e, settings, techNote, message) {
		console.error("DataTables error:", message);
	  }
    });
  });
</script>

<?php get_footer(); ?>