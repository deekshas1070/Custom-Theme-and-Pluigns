<?php
global $wpdb;
$table_name = $wpdb->prefix . 'candle_burn_form';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['entry_id']) && $_SESSION['entry_id'] != '' && $_SESSION['entry_id'] != 0) {
    if (isset($_GET['form_id']) && !empty($_GET['form_id'])) {
        $_SESSION['entry_id'] = intval($_GET['form_id']);
    }
}

$form_data = isset($_POST['formData']) ? $_POST['formData'] : [];
if (isset($form_data['step'])) {
    $step = $form_data['step'];
} else {
    wp_send_json_error(['message' => 'Step ID is missing.']);
    return;
}

$current_user = wp_get_current_user();
$user_id = $current_user->ID;

if($step == 'testDetails'){

    $name = isset($form_data['test_name']) ? sanitize_text_field($form_data['test_name']) : '';
    $date = isset($form_data['date']) ? sanitize_text_field($form_data['date']) : '';
    $indoor_temperature = isset($form_data['indoor_temp']) ? floatval($form_data['indoor_temp']) : 0;
    $outdoor_temperature = isset($form_data['outdoor_temp']) ? floatval($form_data['outdoor_temp']) : 0;

    if (isset($_SESSION['entry_id']) || $_SESSION['entry_id'] > 0) {
        $entry_id = $_SESSION['entry_id'];
        
        $wpdb->update(
            $table_name,
            [
                'name' => $name,
                'date' => $date,
                'indoor_temperature' => $indoor_temperature,
                'outdoor_temperature' => $outdoor_temperature,
                'form_step' => 1,
                'form_status' => 'Processing'
            ],
            ['ID' => $entry_id]
        );
        wp_send_json_success([
            'message' => 'Form data updated successfully.',
            'entry_id' => $entry_id,
        ]);
    } else {
        $wpdb->insert(
            $table_name,
            [
                'user_id'=>$user_id,
                'name' => $name,
                'date' => $date,
                'indoor_temperature' => $indoor_temperature,
                'outdoor_temperature' => $outdoor_temperature,
                'form_step' => 1,
                'form_status' => 'Processing'
            ]
        );
        $inserted_id = $wpdb->insert_id;

        $_SESSION['entry_id'] = $inserted_id;

        wp_send_json_success([
            'message' => 'Form data received and saved successfully.',
            'received_data' => $form_data,
            'entry_id' => $inserted_id,
        ]);
    }
} else if($step == 'infoSlide1'){
    if (isset($_SESSION['entry_id']) || $_SESSION['entry_id'] > 0) {
        $entry_id = $_SESSION['entry_id'];
        $wpdb->update(
            $table_name,
            [
                'form_step' => 2,
                'form_status' => 'Processing'
                                        
            ],
            ['ID' => $entry_id]
        );
        wp_send_json_success([
            'message' => 'Form data updated successfully.',
            'entry_id' => $entry_id,
        ]);
    }
} else if($step == 'materialDetails'){

        $type_of_wax = isset($form_data['type_of_wax']) ? sanitize_text_field($form_data['type_of_wax']) : '';
        $wax_supplier = isset($form_data['wax_supplier']) ? sanitize_text_field($form_data['wax_supplier']) : '';
        $amount_of_wax = isset($form_data['amount_of_wax']) ? sanitize_text_field($form_data['amount_of_wax']) : '';
        $type_of_wick = isset($form_data['type_of_wick']) ? sanitize_text_field($form_data['type_of_wick']) : '';
        $number_of_wicks = isset($form_data['number_of_wicks']) ? sanitize_text_field($form_data['number_of_wicks']) : '';
        $wick_supplier = isset($form_data['wick_supplier']) ? sanitize_text_field($form_data['wick_supplier']) : '';
        $fragrance_oil_name = isset($form_data['fragrance_oil_name']) ? sanitize_text_field($form_data['fragrance_oil_name']) : '';
        $fragrance_volume_load = isset($form_data['fragrance_volume_load']) ? sanitize_text_field($form_data['fragrance_volume_load']) : '';
        $fragrance_supplier = isset($form_data['fragrance_supplier']) ? sanitize_text_field($form_data['fragrance_supplier']) : '';
        $has_dye_color = isset($form_data['has_dye_color']) ? sanitize_text_field($form_data['has_dye_color']) : '';
        $dye_color = isset($form_data['dye_color']) ? sanitize_text_field($form_data['dye_color']) : '';
        $volume_of_dye = isset($form_data['volume_of_dye']) ? sanitize_text_field($form_data['volume_of_dye']) : '';
        $has_dye_stabilizer = isset($form_data['has_dye_stabilizer']) ? sanitize_text_field($form_data['has_dye_stabilizer']) : '';
        $stabilizer_type = isset($form_data['stabilizer_type']) ? sanitize_text_field($form_data['stabilizer_type']) : '';
        $volume_of_dye_stabilizer = isset($form_data['volume_of_dye_stabilizer']) ? sanitize_text_field($form_data['volume_of_dye_stabilizer']) : '';
        $wax_melting_temp = isset($form_data['wax_melting_temp']) ? sanitize_text_field($form_data['wax_melting_temp']) : '';
        $blending_temp = isset($form_data['blending_temp']) ? sanitize_text_field($form_data['blending_temp']) : '';
        $pouring_temp = isset($form_data['pouring_temp']) ? sanitize_text_field($form_data['pouring_temp']) : '';
        $cooling_time = isset($form_data['cooling_time']) ? sanitize_text_field($form_data['cooling_time']) : '';
        $container_type = isset($form_data['container_type']) ? sanitize_text_field($form_data['container_type']) : '';
        $container_supplier = isset($form_data['container_supplier']) ? sanitize_text_field($form_data['container_supplier']) : '';
        $container_size = isset($form_data['container_size']) ? sanitize_text_field($form_data['container_size']) : '';

        if (isset($_SESSION['entry_id']) && $_SESSION['entry_id'] > 0) {
            $entry_id = $_SESSION['entry_id'];
            $wpdb->update(
                $table_name,
                [
                    'wax_type' => $type_of_wax,
                    'wax_supplier' => $wax_supplier,
                    'wax_amount' => $amount_of_wax,
                    'wick_type' => $type_of_wick,
                    'wick_number' => $number_of_wicks,
                    'wick_supplier' => $wick_supplier,
                    'fragrance_oil_name' => $fragrance_oil_name,
                    'volume_and_percentage_load' => $fragrance_volume_load,
                    'fragrance_supplier' => $fragrance_supplier,
                    'has_dye_color' => $has_dye_color,
                    'dye_color' => $dye_color,
                    'volume_of_dye' => $volume_of_dye,
                    'dye_stabilizer' => $has_dye_stabilizer,
                    'stabilizer_type' => $stabilizer_type,
                    'volume_of_dye_stabilizer' => $volume_of_dye_stabilizer,
                    'wax_melting_temperature' => $wax_melting_temp,
                    'blending_temperature' => $blending_temp,
                    'pouring_temperature' => $pouring_temp,
                    'cooling_time' => $cooling_time,
                    'container_type' => $container_type,
                    'container_supplier' => $container_supplier,
                    'container_size' => $container_size,
                    'form_step' => 3,
                    'form_status' => 'Ready to Burn'
                                            
                ],
                ['ID' => $entry_id]
            );

            wp_send_json_success([
                'message' => 'Form data updated successfully.',
                'entry_id' => $entry_id,
            ]);
        }

} else if($step == 'infoSlide2'){
    if (isset($_SESSION['entry_id']) && $_SESSION['entry_id'] > 0) {
        $entry_id = $_SESSION['entry_id'];
        $wpdb->update(
            $table_name,
            [
                'form_step' => 4,
                'form_status' => 'Processing'
                                        
            ],
            ['ID' => $entry_id]
        );

        wp_send_json_success([
            'message' => 'Form data updated successfully.',
            'entry_id' => $entry_id,
        ]);
    }
} else if($step == 'performanceDetails'){
    $cold_fragrance_throw = isset($form_data['cold_fragrance_throw']) ? sanitize_text_field($form_data['cold_fragrance_throw']) : '';
    $visible_frosting = isset($form_data['visible_frosting']) ? sanitize_text_field($form_data['visible_frosting']) : '';
    $frosting_location = isset($form_data['frosting_location']) ? sanitize_text_field($form_data['frosting_location']) : '';
    $frosting_amount = isset($form_data['frosting_amount']) ? sanitize_text_field($form_data['frosting_amount']) : '';
    $melt_to_edge_1 = isset($form_data['melt_to_edge_1']) ? sanitize_text_field($form_data['melt_to_edge_1']) : '';
    $melt_pool_depth_1 = isset($form_data['melt_pool_depth_1']) ? sanitize_text_field($form_data['melt_pool_depth_1']) : '';
    $smoking_1 = isset($form_data['smoking_1']) ? sanitize_text_field($form_data['smoking_1']) : '';
    $notes_1 = isset($form_data['notes_1']) ? sanitize_text_field($form_data['notes_1']) : '';
    $melt_to_edge_2 = isset($form_data['melt_to_edge_2']) ? sanitize_text_field($form_data['melt_to_edge_2']) : '';
    $melt_pool_depth_2 = isset($form_data['melt_pool_depth_2']) ? sanitize_text_field($form_data['melt_pool_depth_2']) : '';
    $smoking_2 = isset($form_data['smoking_2']) ? sanitize_text_field($form_data['smoking_2']) : '';
    $notes_2 = isset($form_data['notes_2']) ? sanitize_text_field($form_data['notes_2']) : '';
    $melt_to_edge_3 = isset($form_data['melt_to_edge_3']) ? sanitize_text_field($form_data['melt_to_edge_3']) : '';
    $melt_pool_depth_3 = isset($form_data['melt_pool_depth_3']) ? sanitize_text_field($form_data['melt_pool_depth_3']) : '';
    $smoking_3 = isset($form_data['smoking_3']) ? sanitize_text_field($form_data['smoking_3']) : '';
    $notes_3 = isset($form_data['notes_3']) ? sanitize_text_field($form_data['notes_3']) : '';
    $melt_to_edge_4 = isset($form_data['melt_to_edge_4']) ? sanitize_text_field($form_data['melt_to_edge_4']) : '';
    $melt_pool_depth_4 = isset($form_data['melt_pool_depth_4']) ? sanitize_text_field($form_data['melt_pool_depth_4']) : '';
    $smoking_4 = isset($form_data['smoking_4']) ? sanitize_text_field($form_data['smoking_4']) : '';
    $notes_4 = isset($form_data['notes_4']) ? sanitize_text_field($form_data['notes_4']) : '';

    if (isset($_SESSION['entry_id']) && $_SESSION['entry_id'] > 0) {
        $entry_id = $_SESSION['entry_id'];
        $wpdb->update(
            $table_name,
            [
                'cold_fragrance_throw_rating' => $cold_fragrance_throw,
                'has_visible_frosting' => $visible_frosting,
                'visible_frosting' => $frosting_location,
                'visible_frosting_amount' => $frosting_amount,
                'percent_melted_edge_1_hr' => $melt_to_edge_1,
                'melt_pool_depth_1_hr' => $melt_pool_depth_1,
                'smoking_amount_1_hr' => $smoking_1,
                'notes_1_hr' => $notes_1,
                'percent_melted_edge_2_hr' => $melt_to_edge_2,
                'melt_pool_depth_2_hr' => $melt_pool_depth_2,
                'smoking_amount_2_hr' => $smoking_2,
                'notes_2_hr' => $notes_2,
                'percent_melted_edge_3_hr' => $melt_to_edge_3,
                'melt_pool_depth_3_hr' => $melt_pool_depth_3,
                'smoking_amount_3_hr' => $smoking_3,
                'notes_3_hr' => $notes_3,
                'percent_melted_edge_4_hr' => $melt_to_edge_4,
                'melt_pool_depth_4_hr' => $melt_pool_depth_4,
                'smoking_amount_4_hr' => $smoking_4,
                'notes_4_hr' => $notes_4,
                'form_step' => 5,
                'form_status' => 'Processing'
                                        
            ],
            ['ID' => $entry_id]
        );

        wp_send_json_success([
            'message' => 'Form data updated successfully.',
            'entry_id' => $entry_id,
        ]);
    }
} else if($step == 'notes') {
    $additional_notes = isset($form_data['notes']) ? sanitize_text_field($form_data['notes']) : '';
    if (isset($_SESSION['entry_id']) && $_SESSION['entry_id'] > 0) {
        $entry_id = $_SESSION['entry_id'];

        $wpdb->update(
            $table_name,
            [
                'additional_notes' => $additional_notes,
                'form_step' => 6,
                'form_status' => 'Completed'
            ],
            ['ID' => $entry_id] 
        );
        
       // require_once plugin_dir_path( __FILE__ ) . 'mails\emailer.php';
        unset($_SESSION['entry_id']);
        session_unset();
        session_destroy();

        wp_send_json_success([
            'message' => 'Complete form data updated successfully.',
            'redirect' => true,
            'entry_id' => $entry_id,
        ]);
    }
}