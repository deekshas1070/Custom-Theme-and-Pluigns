<?php
$current_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$referrer = isset($_SERVER['HTTP_REFERER']) ? parse_url($_SERVER['HTTP_REFERER'], PHP_URL_PATH) : '';
if ($current_path !== '/my-account/tools-form/') {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    session_unset();
    session_destroy();
    return;
}
if ($referrer !== '' && $referrer !== '/my-account/tools-form/'  ) {  
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    session_unset();
    session_destroy();
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

global $wpdb;

if (isset($_GET['form_id']) && !empty($_GET['form_id'])) {
    $_SESSION['entry_id'] = intval($_GET['form_id']);
}

if (isset($_SESSION['entry_id']) && $_SESSION['entry_id'] > 0) {
    $entry_id = $_SESSION['entry_id'];
    $table_name = $wpdb->prefix . "candle_burn_form";

    $form_data = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $entry_id),
        ARRAY_A
    );

    if ($form_data) {
        if (isset($form_data['form_status']) && $form_data['form_status'] === 'Submitted') {
            wp_redirect(home_url('/my-account/form-list/'));
            unset($_SESSION['entry_id']); 
            session_unset();
            session_destroy();
            exit;
        }
        $_SESSION['form_data'] = $form_data;
    }
}
?>