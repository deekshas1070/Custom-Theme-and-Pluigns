<?php 
global $wpdb;
$form_id =$_SESSION['entry_id'];
$table_name = $wpdb->prefix . 'candle_burn_form';
$form_data = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $form_id", ARRAY_A);
$current_user = wp_get_current_user();
$current_loggedin_name = $current_user->display_name;
$user_email = $current_user->user_email;

include 'user_email_template.php';
include 'admin_email_template.php';

send_form_submission_email('user', $user_email, $user_email_html);

// send_form_submission_email('admin',"jacob@wiccandleco.com.au", $admin_email_html);
send_form_submission_email('admin',"deekshasharma.tm@gmail.com", $admin_email_html);

function send_form_submission_email($type, $email, $emailTemp) {
    $from_email = defined('SENDGRID_FROM_EMAIL') ? constant('SENDGRID_FROM_EMAIL') : 'no-reply@wicsupplies.com';
    $from_name = defined('SENDGRID_FROM_NAME') ? constant('SENDGRID_FROM_NAME') : 'WICSUPPLIES';

    if ($type == 'user') {
        $subject = "Thank you for contacting us!";
        $message = $emailTemp;
    } elseif ($type == 'admin') {
        $subject = "New Form Submission";
        $message = $emailTemp;
    } else {
        return;
    }

    $headers = [
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $from_name . ' <' . $from_email . '>',
    ];

    if (wp_mail($email, $subject, $message, $headers)) {
        error_log("Email sent successfully to $email");
    } else {
        error_log("Failed to send email to $email");
    }
}