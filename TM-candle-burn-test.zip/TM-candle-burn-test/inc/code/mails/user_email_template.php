<?php 
$user_email_html = ' <table bgcolor="#003b5d" width="100%" align="center" cellspacing="0" cellpadding="0" style="background-color: #ffffff;">
    <tbody>
        <tr>
            <td>
                <table bgcolor="#003b5d" align="center" width="600" style="background-color: #dddddd;max-width: 600px;width: 600px;font-family: Arial,  sans-serif;margin: 0 auto;padding: 25px 0;-webkit-border-horizontal-spacing: 0px;-webkit-border-vertical-spacing: 0px;table-layout: fixed;" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td>
                                <table bgcolor="#ffffff" align="center" width="600" style="background-color: #f3f3f3;max-width: 600px;width: 600px;font-family: Arial,  sans-serif;margin: 0 auto;padding: 0;-webkit-border-horizontal-spacing: 0px;-webkit-border-vertical-spacing: 0px;border-collapse: collapse;" cellspacing="0" cellpadding="0">
                                    <tbody>
                                        <tr>
                                            <td style="border: 1px solid #f3f3f3; padding: 10px;color: #333333; width: 100%; vertical-align: top;padding:20px 15px" width="100%" valign="top">
                                                <p style="font-size: 16px;color: #000000;">
                                                    Hi '.$current_loggedin_name.'
                                                    <br><br>
                                                    Thank you for contacting us
                                                    <br><br>
                                                    We have received your enquiry. 
                                                    <br><br>
                                                    Please allow up to one working day for our sales representatives to get in touch make the necessary arrangements. 
                                                    <br><br>
                                                    <strong>The WIC supplies team</strong>
                                                    <br><br>
                                                </p>
                                                <p style="font-size: 16px;color:#888888">
                                                    Note: This was generated automatically. Please do not reply. 
                                                    <br>
                                                    Replies to automated messsges are not monitored.
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
';

?>