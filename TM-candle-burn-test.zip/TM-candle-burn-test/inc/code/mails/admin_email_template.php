<?php
$admin_email_html = '<table width="100%" align="center" cellspacing="0" cellpadding="0">
    <tbody>
        <tr>
            <td>
                <table bgcolor="#ffffff" align="center" width="600" style="background-color: #ffffff;max-width: 600px;width: 600px;font-family: Arial, sans-serif;margin: 0 auto;padding: 0;-webkit-border-horizontal-spacing: 0px;-webkit-border-vertical-spacing: 0px;table-layout: fixed;"
                    cellspacing="0" cellpadding="0">
                    <tbody>
                        <!-- Header start here -->
                        <tr>
                            <td align="center" style="text-align: center;border-bottom: 10px solid white;background: #ffffff; border-top: 10px solid white;padding: 10px 0; vertical-align: middle;" valign="middle">
                                <a href="https://wicsupplies.tmdemo.in/" target="_blank" style="display: inline-block;">
                                    <img src="https://wicsupplies.tmdemo.in/wp-content/uploads/2025/01/Wic_Supplies_180_x_40_px_2_1-1400x317.png" alt="Logo" style="width: 150px;" width="150">
                                </a>
                            </td>
                        </tr>
                        <!-- table start here -->
                        <tr>
                            <td>
                                <table bgcolor="#ffffff" align="center" width="599" style="background-color: #ffffff;max-width: 599px;width: 599px;font-family: Arial, sans-serif;margin: 0 auto;padding: 0;-webkit-border-horizontal-spacing: 0px;-webkit-border-vertical-spacing: 0px;border-collapse: collapse;"
                                    cellspacing="0" cellpadding="0">
                                    <tbody>
                                        <tr>
                                            <td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333; width: 45%; vertical-align: top;" width="45%" valign="top">
                                                <p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Name</p>
                                            </td>
                                            <td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333; width: 55%; vertical-align: top;" width="55%" valign="top">
                                                <p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">'.$current_loggedin_name.'</p>
                                            </td>
                                        </tr>';

								if (!empty($form_data['name'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Test Name</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['name'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['date'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Date</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['date'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['indoor_temperature'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Indoor Temperature</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['indoor_temperature'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['outdoor_temperature'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Outdoor Temperature</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['outdoor_temperature'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['wax_type'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Wax Type</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['wax_type'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['wax_supplier'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Wax Supplier</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['wax_supplier'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['wax_amount'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Wax Amount</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['wax_amount'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['wick_type'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Wick Type</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['wick_type'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['wick_number'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Wick Number</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['wick_number'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['wick_supplier'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Wick Supplier</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['wick_supplier'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['fragrance_oil_name'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Fragrance Oil Name</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['fragrance_oil_name'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['volume_and_percentage_load'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Volume and Percentage Load</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['volume_and_percentage_load'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['fragrance_supplier'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Fragrance Supplier</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['fragrance_supplier'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['has_dye_color'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Has Dye Color</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['has_dye_color'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['dye_color'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Dye Color</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['dye_color'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['volume_of_dye'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Volume of Dye</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['volume_of_dye'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['dye_stabilizer'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Dye Stabilizer</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['dye_stabilizer'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['stabilizer_type'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Stabilizer Type</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['stabilizer_type'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['volume_of_dye_stabilizer'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Volume of Dye Stabilizer</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['volume_of_dye_stabilizer'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['wax_melting_temperature'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Wax Melting Temperature</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['wax_melting_temperature'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['blending_temperature'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Blending Temperature</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['blending_temperature'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['pouring_temperature'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Pouring Temperature</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['pouring_temperature'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['cooling_time'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Cooling Time</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['cooling_time'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['container_type'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Container Type</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['container_type'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['container_supplier'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Container Supplier</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['container_supplier'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['container_size'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Container Size</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['container_size'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['cold_fragrance_throw_rating'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Cold Fragrance Throw Rating</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['cold_fragrance_throw_rating'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['has_visible_frosting'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Has Visible Frosting</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['has_visible_frosting'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['visible_frosting'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Visible Frosting</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['visible_frosting'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['visible_frosting_amount'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Visible Frosting Amount</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['visible_frosting_amount'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['percent_melted_edge_1_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Percent Melted Edge (1 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['percent_melted_edge_1_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['melt_pool_depth_1_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Melt Pool Depth (1 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['melt_pool_depth_1_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['smoking_amount_1_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Smoking Amount (1 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['smoking_amount_1_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['notes_1_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Notes (1 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['notes_1_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['percent_melted_edge_2_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Percent Melted Edge (2 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['percent_melted_edge_2_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['melt_pool_depth_2_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Melt Pool Depth (2 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['melt_pool_depth_2_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['smoking_amount_2_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Smoking Amount (2 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['smoking_amount_2_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['notes_2_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Notes (2 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['notes_2_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['notes_2_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Notes (2 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['notes_2_hr'] . '</p>
										</td>
									</tr>';
								}


								if (!empty($form_data['percent_melted_edge_3_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Percent Melted Edge (3 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['percent_melted_edge_3_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['melt_pool_depth_3_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Melt Pool Depth (3 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['melt_pool_depth_3_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['smoking_amount_3_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Smoking Amount (3 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['smoking_amount_3_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['notes_3_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Notes (3 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['notes_3_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['percent_melted_edge_4_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Percent Melted Edge (4 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['percent_melted_edge_4_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['melt_pool_depth_4_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Melt Pool Depth (4 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['melt_pool_depth_4_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['smoking_amount_4_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Smoking Amount (4 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['smoking_amount_4_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['notes_4_hr'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Notes (4 hr)</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['notes_4_hr'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['additional_notes'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Additional Notes</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['additional_notes'] . '</p>
										</td>
									</tr>';
								}

								if (!empty($form_data['form_status'])) {
									$admin_email_html .= '<tr>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 600;color: #333333;">Form Status</p>
										</td>
										<td style="border: 1px solid #bfc8d0; padding: 10px;color: #333333;" valign="top">
											<p style="margin: 0;font-size: 14px;font-weight: 400;color: #333333;">' . $form_data['form_status'] . '</p>
										</td>
									</tr>';
								}


								$admin_email_html .= '</tbody>
													</table>
												</td>
											</tr>
											<!-- Footer start here -->
											<tr>
												<td align="center" style="text-align: center;background-color: #000;padding: 0;border-top: 20px solid #fff; vertical-align: middle;" bgcolor="#333f48" valign="middle">
													<p style="text-align: center;font-size: 13px;padding: 0px 15px;color: #fff;margin: 20px 0;font-weight:600">© Copyright 2025 wicsupplies. All Rights Reserved.</p>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>';