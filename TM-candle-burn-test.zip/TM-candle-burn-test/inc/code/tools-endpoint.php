<?php 
add_action( 'woocommerce_account_tools_endpoint', 'tm_tools_my_account_endpoint_content' );
function tm_tools_my_account_endpoint_content() {
    require_once plugin_dir_path( __DIR__ ) . '\files\grid-html.php';
}

add_filter( 'woocommerce_account_menu_items', 'tm_add_tools_link_to_menu' );
function tm_add_tools_link_to_menu( $items ) {
    $items['tools'] = 'Tools';
    return $items;
}

function tm_add_form_list_endpoint() {
    add_rewrite_endpoint( 'form-list', EP_ROOT | EP_PAGES );
}
add_action( 'init', 'tm_add_form_list_endpoint' );

add_action( 'woocommerce_account_form-list_endpoint', 'tools_sub_page_endpoint_content' );
function tools_sub_page_endpoint_content() {
   require_once plugin_dir_path( __DIR__ ) . '\files\tools-form-list-html.php';
}

function tm_add_tools_form_endpoint() {
    add_rewrite_endpoint( 'tools-form', EP_ROOT | EP_PAGES );
}
add_action( 'init', 'tm_add_tools_form_endpoint' );

add_action( 'woocommerce_account_tools-form_endpoint', 'tools_form_sub_page_endpoint_content' );
function tools_form_sub_page_endpoint_content() {
   require_once plugin_dir_path( __DIR__ ) . '\files\tools-form-html.php';
}
?>
