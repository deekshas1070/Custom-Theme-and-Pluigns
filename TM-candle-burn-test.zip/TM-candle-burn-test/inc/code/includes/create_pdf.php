<?php
use Dompdf\Dompdf;
use Dompdf\Options;

require 'vendor/autoload.php';  

global $wpdb;

$table_name = $wpdb->prefix . 'candle_burn_form';
$form_data = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $form_id", ARRAY_A);


$html = '';
$html .= "
    <html>
    <head>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 20px;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }
            table, th, td {
                border: 1px solid #000;
            }
            th, td {
                padding: 8px;
                text-align: left;
            }
            th {
                background-color: #f2f2f2;
            }
            h2 {
                text-align: center;
            }
        </style>
    </head>
    <body>
      <h2>Candle Burn Form Data</h2>
    <table>";

		if (isset($form_data['name']) && !empty($form_data['name'])) {
			$html .= "<tr><th>Test Name</th><td>" . $form_data['name'] . "</td></tr>";
		}

		if (isset($form_data['date']) && !empty($form_data['date'])) {
			$html .= "<tr><th>Date</th><td>" . $form_data['date'] . "</td></tr>";
		}

		if (isset($form_data['indoor_temperature']) && !empty($form_data['indoor_temperature'])) {
			$html .= "<tr><th>Indoor Temperature</th><td>" . $form_data['indoor_temperature'] . "</td></tr>";
		}

		if (isset($form_data['outdoor_temperature']) && !empty($form_data['outdoor_temperature'])) {
			$html .= "<tr><th>Outdoor Temperature</th><td>" . $form_data['outdoor_temperature'] . "</td></tr>";
		}

		if (isset($form_data['form_status']) && !empty($form_data['form_status'])) {
			$html .= "<tr><th>Form Status</th><td>" . $form_data['form_status'] . "</td></tr>";
		}

		if (isset($form_data['form_step']) && !empty($form_data['form_step'])) {
			$html .= "<tr><th>Form Step</th><td>" . $form_data['form_step'] . "</td></tr>";
		}

		if (isset($form_data['wax_type']) && !empty($form_data['wax_type'])) {
			$html .= "<tr><th>Wax Type</th><td>" . $form_data['wax_type'] . "</td></tr>";
		}

		if (isset($form_data['wax_supplier']) && !empty($form_data['wax_supplier'])) {
			$html .= "<tr><th>Wax Supplier</th><td>" . $form_data['wax_supplier'] . "</td></tr>";
		}

		if (isset($form_data['wax_amount']) && !empty($form_data['wax_amount'])) {
			$html .= "<tr><th>Wax Amount</th><td>" . $form_data['wax_amount'] . "</td></tr>";
		}

		if (isset($form_data['wick_type']) && !empty($form_data['wick_type'])) {
			$html .= "<tr><th>Wick Type</th><td>" . $form_data['wick_type'] . "</td></tr>";
		}

		if (isset($form_data['wick_number']) && !empty($form_data['wick_number'])) {
			$html .= "<tr><th>Wick Number</th><td>" . $form_data['wick_number'] . "</td></tr>";
		}

		if (isset($form_data['wick_supplier']) && !empty($form_data['wick_supplier'])) {
			$html .= "<tr><th>Wick Supplier</th><td>" . $form_data['wick_supplier'] . "</td></tr>";
		}

		if (isset($form_data['fragrance_oil_name']) && !empty($form_data['fragrance_oil_name'])) {
			$html .= "<tr><th>Fragrance Oil Name</th><td>" . $form_data['fragrance_oil_name'] . "</td></tr>";
		}

		if (isset($form_data['volume_and_percentage_load']) && !empty($form_data['volume_and_percentage_load'])) {
			$html .= "<tr><th>Volume and Percentage Load</th><td>" . $form_data['volume_and_percentage_load'] . "</td></tr>";
		}

		if (isset($form_data['fragrance_supplier']) && !empty($form_data['fragrance_supplier'])) {
			$html .= "<tr><th>Fragrance Supplier</th><td>" . $form_data['fragrance_supplier'] . "</td></tr>";
		}

		if (isset($form_data['has_dye_color']) && !empty($form_data['has_dye_color'])) {
			$html .= "<tr><th>Has Dye Color</th><td>" . $form_data['has_dye_color'] . "</td></tr>";
		}

		if (isset($form_data['dye_color']) && !empty($form_data['dye_color'])) {
			$html .= "<tr><th>Dye Color</th><td>" . $form_data['dye_color'] . "</td></tr>";
		}

		if (isset($form_data['volume_of_dye']) && !empty($form_data['volume_of_dye'])) {
			$html .= "<tr><th>Volume of Dye</th><td>" . $form_data['volume_of_dye'] . "</td></tr>";
		}

		if (isset($form_data['dye_stabilizer']) && !empty($form_data['dye_stabilizer'])) {
			$html .= "<tr><th>Dye Stabilizer</th><td>" . $form_data['dye_stabilizer'] . "</td></tr>";
		}

		if (isset($form_data['volume_of_dye_stabilizer']) && !empty($form_data['volume_of_dye_stabilizer'])) {
			$html .= "<tr><th>Volume of Dye Stabilizer</th><td>" . $form_data['volume_of_dye_stabilizer'] . "</td></tr>";
		}

		if (isset($form_data['wax_melting_temperature']) && !empty($form_data['wax_melting_temperature'])) {
			$html .= "<tr><th>Wax Melting Temperature</th><td>" . $form_data['wax_melting_temperature'] . "</td></tr>";
		}

		if (isset($form_data['blending_temperature']) && !empty($form_data['blending_temperature'])) {
			$html .= "<tr><th>Blending Temperature</th><td>" . $form_data['blending_temperature'] . "</td></tr>";
		}

		if (isset($form_data['pouring_temperature']) && !empty($form_data['pouring_temperature'])) {
			$html .= "<tr><th>Pouring Temperature</th><td>" . $form_data['pouring_temperature'] . "</td></tr>";
		}

		if (isset($form_data['cooling_time']) && !empty($form_data['cooling_time'])) {
			$html .= "<tr><th>Cooling Time</th><td>" . $form_data['cooling_time'] . "</td></tr>";
		}

		if (isset($form_data['container_type']) && !empty($form_data['container_type'])) {
			$html .= "<tr><th>Container Type</th><td>" . $form_data['container_type'] . "</td></tr>";
		}

		if (isset($form_data['container_supplier']) && !empty($form_data['container_supplier'])) {
			$html .= "<tr><th>Container Supplier</th><td>" . $form_data['container_supplier'] . "</td></tr>";
		}

		if (isset($form_data['container_size']) && !empty($form_data['container_size'])) {
			$html .= "<tr><th>Container Size</th><td>" . $form_data['container_size'] . "</td></tr>";
		}

		if (isset($form_data['cold_fragrance_throw_rating']) && !empty($form_data['cold_fragrance_throw_rating'])) {
			$html .= "<tr><th>Cold Fragrance Throw Rating</th><td>" . $form_data['cold_fragrance_throw_rating'] . "</td></tr>";
		}

		if (isset($form_data['has_visible_frosting']) && !empty($form_data['has_visible_frosting'])) {
			$html .= "<tr><th>Has Visible Frosting</th><td>" . $form_data['has_visible_frosting'] . "</td></tr>";
		}

		if (isset($form_data['visible_frosting']) && !empty($form_data['visible_frosting'])) {
			$html .= "<tr><th>Visible Frosting</th><td>" . $form_data['visible_frosting'] . "</td></tr>";
		}

		if (isset($form_data['visible_frosting_amount']) && !empty($form_data['visible_frosting_amount'])) {
			$html .= "<tr><th>Visible Frosting Amount</th><td>" . $form_data['visible_frosting_amount'] . "</td></tr>";
		}

		if (isset($form_data['percent_melted_edge_1_hr']) && !empty($form_data['percent_melted_edge_1_hr'])) {
			$html .= "<tr><th>Percent Melted Edge (1hr)</th><td>" . $form_data['percent_melted_edge_1_hr'] . "</td></tr>";
		}

		if (isset($form_data['melt_pool_depth_1_hr']) && !empty($form_data['melt_pool_depth_1_hr'])) {
			$html .= "<tr><th>Melt Pool Depth (1hr)</th><td>" . $form_data['melt_pool_depth_1_hr'] . "</td></tr>";
		}

		if (isset($form_data['smoking_amount_1_hr']) && !empty($form_data['smoking_amount_1_hr'])) {
			$html .= "<tr><th>Smoking Amount (1hr)</th><td>" . $form_data['smoking_amount_1_hr'] . "</td></tr>";
		}

		if (isset($form_data['notes_1_hr']) && !empty($form_data['notes_1_hr'])) {
			$html .= "<tr><th>Notes (1hr)</th><td>" . $form_data['notes_1_hr'] . "</td></tr>";
		}

		if (isset($form_data['percent_melted_edge_2_hr']) && !empty($form_data['percent_melted_edge_2_hr'])) {
			$html .= "<tr><th>Percent Melted Edge (2hrs)</th><td>" . $form_data['percent_melted_edge_2_hr'] . "</td></tr>";
		}

		if (isset($form_data['melt_pool_depth_2_hr']) && !empty($form_data['melt_pool_depth_2_hr'])) {
			$html .= "<tr><th>Melt Pool Depth (2hrs)</th><td>" . $form_data['melt_pool_depth_2_hr'] . "</td></tr>";
		}

		if (isset($form_data['smoking_amount_2_hr']) && !empty($form_data['smoking_amount_2_hr'])) {
			$html .= "<tr><th>Smoking Amount (2hrs)</th><td>" . $form_data['smoking_amount_2_hr'] . "</td></tr>";
		}

		if (isset($form_data['notes_2_hr']) && !empty($form_data['notes_2_hr'])) {
			$html .= "<tr><th>Notes (2hrs)</th><td>" . $form_data['notes_2_hr'] . "</td></tr>";
		}


		if (isset($form_data['percent_melted_edge_3_hr']) && !empty($form_data['percent_melted_edge_3_hr'])) {
			$html .= "<tr><th>Percent Melted Edge (3hrs)</th><td>" . $form_data['percent_melted_edge_3_hr'] . "</td></tr>";
		}

		if (isset($form_data['melt_pool_depth_3_hr']) && !empty($form_data['melt_pool_depth_3_hr'])) {
			$html .= "<tr><th>Melt Pool Depth (3hrs)</th><td>" . $form_data['melt_pool_depth_3_hr'] . "</td></tr>";
		}

		if (isset($form_data['smoking_amount_3_hr']) && !empty($form_data['smoking_amount_3_hr'])) {
			$html .= "<tr><th>Smoking Amount (3hrs)</th><td>" . $form_data['smoking_amount_3_hr'] . "</td></tr>";
		}

		if (isset($form_data['notes_3_hr']) && !empty($form_data['notes_3_hr'])) {
			$html .= "<tr><th>Notes (3hrs)</th><td>" . $form_data['notes_3_hr'] . "</td></tr>";
		}

		if (isset($form_data['percent_melted_edge_4_hr']) && !empty($form_data['percent_melted_edge_4_hr'])) {
			$html .= "<tr><th>Percent Melted Edge (4hrs)</th><td>" . $form_data['percent_melted_edge_4_hr'] . "</td></tr>";
		}

		if (isset($form_data['melt_pool_depth_4_hr']) && !empty($form_data['melt_pool_depth_4_hr'])) {
			$html .= "<tr><th>Melt Pool Depth (4hrs)</th><td>" . $form_data['melt_pool_depth_4_hr'] . "</td></tr>";
		}

		if (isset($form_data['smoking_amount_4_hr']) && !empty($form_data['smoking_amount_4_hr'])) {
			$html .= "<tr><th>Smoking Amount (4hrs)</th><td>" . $form_data['smoking_amount_4_hr'] . "</td></tr>";
		}

		if (isset($form_data['notes_4_hr']) && !empty($form_data['notes_4_hr'])) {
			$html .= "<tr><th>Notes (4hrs)</th><td>" . $form_data['notes_4_hr'] . "</td></tr>";
		}

		if (isset($form_data['additional_notes']) && !empty($form_data['additional_notes'])) {
			$html .= "<tr><th>Additional Notes</th><td>" . $form_data['additional_notes'] . "</td></tr>";
		}

	$html .= "</table></body></html>";
	$html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');
    $dompdf = new DOMPDF(array(
        'enable_remote' => true
    ));
    // $file_name = 'pdf_data/form_' . $form_id . '.pdf';
    $dompdf->load_html($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $output = $dompdf->output();
	$base64_pdf = base64_encode($output);
	header('Content-Type: application/json');
	header('Access-Control-Allow-Origin: *'); 
	wp_send_json_success([
		'pdf' => $base64_pdf,
		'pdf_url' => 'data:application/pdf;base64,' . $base64_pdf, // Direct URL to the PDF file
		'message' => 'PDF generated successfully.',
		'html_content' =>$html
	]); 
